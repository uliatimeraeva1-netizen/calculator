package com.example.das;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView resultField;
    private EditText numberField;
    private TextView operationField;

    private Double operand = null;
    private String lastOperation = "=";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resultField = findViewById(R.id.resultField);
        numberField = findViewById(R.id.numberField);
        operationField = findViewById(R.id.operationField);

        // Обработчики математических операций
        findViewById(R.id.add).setOnClickListener(v -> onOperationClick("+"));
        findViewById(R.id.sub).setOnClickListener(v -> onOperationClick("-"));
        findViewById(R.id.mul).setOnClickListener(v -> onOperationClick("*"));
        findViewById(R.id.div).setOnClickListener(v -> onOperationClick("/"));
        findViewById(R.id.eq).setOnClickListener(v -> onOperationClick("="));

        // Обработчики цифр
        findViewById(R.id.n0).setOnClickListener(v -> onNumberClick("0"));
        findViewById(R.id.n1).setOnClickListener(v -> onNumberClick("1"));
        findViewById(R.id.n2).setOnClickListener(v -> onNumberClick("2"));
        findViewById(R.id.n3).setOnClickListener(v -> onNumberClick("3"));
        findViewById(R.id.n4).setOnClickListener(v -> onNumberClick("4"));
        findViewById(R.id.n5).setOnClickListener(v -> onNumberClick("5"));
        findViewById(R.id.n6).setOnClickListener(v -> onNumberClick("6"));
        findViewById(R.id.n7).setOnClickListener(v -> onNumberClick("7"));
        findViewById(R.id.n8).setOnClickListener(v -> onNumberClick("8"));
        findViewById(R.id.n9).setOnClickListener(v -> onNumberClick("9"));
        findViewById(R.id.comma).setOnClickListener(v -> onNumberClick(","));

        // Обработчики дополнительных операций
        findViewById(R.id.coren).setOnClickListener(v -> onOperationClick("√"));
        findViewById(R.id.proc).setOnClickListener(v -> onOperationClick("%"));
        findViewById(R.id.clear).setOnClickListener(v -> onClearClick());
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("OPERATION", lastOperation);
        if (operand != null) {
            outState.putDouble("OPERAND", operand);
        }
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        lastOperation = savedInstanceState.getString("OPERATION", "=");
        operand = savedInstanceState.getDouble("OPERAND", 0.0);
        if (savedInstanceState.containsKey("OPERAND")) {
            operand = savedInstanceState.getDouble("OPERAND");
            resultField.setText(formatNumber(operand));
        }
        operationField.setText(lastOperation);
    }

    private void onNumberClick(String number) {
        numberField.append(number);
        if ("=".equals(lastOperation) && operand != null) {
            operand = null;
            resultField.setText("");
        }
    }

    private void onOperationClick(String op) {
        String numberStr = numberField.getText().toString().replace(',', '.');
        if (numberStr.length() > 0) {
            try {
                performOperation(Double.parseDouble(numberStr), op);
            } catch (NumberFormatException e) {
                numberField.setText("");
            }
        }
        lastOperation = op;
        operationField.setText(lastOperation);
    }

    private void onClearClick() {
        numberField.setText("");
    }

    private void performOperation(double number, String operation) {
        // Операция с корнем
        if ("√".equals(operation)) {
            if (number < 0) operand = Double.NaN;
            else operand = Math.sqrt(number);
            resultField.setText(formatNumber(operand));
            numberField.setText("");
            return;
        }

        // Операция с процентом
        if ("%".equals(operation)) {
            operand = number / 100.0;
            resultField.setText(formatNumber(operand));
            numberField.setText("");
            return;
        }

        // Основные математические операции
        if (operand == null) {
            operand = number;
        } else {
            if ("=".equals(lastOperation)) {
                lastOperation = operation;
            }
            switch (lastOperation) {
                case "=":
                    operand = number;
                    break;
                case "+":
                    operand = operand + number;
                    break;
                case "-":
                    operand = operand - number;
                    break;
                case "*":
                    operand = operand * number;
                    break;
                case "/":
                    if (number == 0.0) operand = Double.NaN;
                    else operand = operand / number;
                    break;
            }
        }
        resultField.setText(formatNumber(operand));
        numberField.setText("");
    }

    private String formatNumber(double value) {
        if (Double.isNaN(value)) return "Ошибка";
        return String.valueOf(value).replace('.', ',');
    }
}